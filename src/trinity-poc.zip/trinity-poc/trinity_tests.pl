
                /*******************************
                *             TESTS            *
                *******************************/   
            

:- use_module(library(plunit)).
:- use_module(library(debug)).


test :-
   run_tests([ receive,
               actors,
               toplevels,
               compute_answer,
               programs,
               parallel
             ]).


:- begin_tests(receive).
   
test(receive1, X == bar) :-
   self(Self),
   Self ! foo(bar),    
   receive({
       foo(X) -> true
   }).

test(receive2, X == baz) :-
   self(Self),
   Self ! not_matching,    
   Self ! foo(bar),    
   receive({
       foo(X) -> true;
       _ -> X = baz
   }),
   receive({
       foo(_) -> true
   }).    

test(receive3, X == baz) :-
   receive({
       foo(X) -> true
   },[
       timeout(1),
       on_timeout(X = baz)
   ]).

test(receive4, X == baz) :-
   receive({
       foo(X) -> true
   },[
       timeout(0),
       on_timeout(X = baz)
   ]).
   
test(receive5, Result == [hello, goodbye]) :-
   self(S),
   S ! hello,
   S ! goodbye,
   receive({A -> true}),
   receive({B -> true}),
   Result = [A,B].
   
test(receive6, X == baz) :-
   self(S),
   S ! foo(baz),    
   receive({
       foo(X) if true, true -> 
           true
   }).

test(receive7, X == a) :-
   self(S),
   S ! foo,    
   receive({
       foo if p(X) -> 
           true
   }). 
   
test(receive8, X == b) :-
   self(S),
   S ! foo(b),    
   receive({
       foo(X) if p(Y), X=Y -> 
           true
   }).        
       
test(receive9, Result = done) :-
   receive({}, [timeout(1)]),
   Result = done.

test(receive10, Result == done) :-
   self(Self),
   Self ! done,
   receive({
       Result -> true ;
       unreachable ->
           Result = wrong
   }).

test(receive11, Result == done) :-
   self(Self),
   (   true
   ;   Self ! foo(stop),
       receive({
          foo(X) -> 
             Self ! X
       })
   ),
   receive({
      stop -> true
   }, [
       timeout(0),
       on_timeout(fail)
   ]),
   Result = done.
   
:- end_tests(receive).


:- begin_tests(actors).


test(actors2_exit_1, Reason == reason) :-
   spawn(exit(reason), Pid, [
       monitor(true)
   ]),
   receive({
       down(Pid, Reason) -> true
   }).
test(actors2_exit_2, Reason == reason) :-
   spawn((repeat, fail), Pid, [
       monitor(true)
   ]),
   exit(Pid, reason),
   receive({
       down(Pid, Reason) -> true
   }).
test(actors3_register_1, Msg == hello) :-
   self(Pid),
   register(test, Pid),
   test ! hello,
   unregister(test),
   receive({
       Msg -> true
   }).
test(actors3_register_2, Reason == reason) :-
   spawn((repeat, fail), Pid, [
      monitor(true)
   ]),
   register(test2, Pid),
   whereis(test2, Pid2),
   exit(Pid2, reason),
   whereis(test2, undefined),
   unregister(test2),
   receive({
       down(Pid2, Reason) -> true
   }).
    
:- end_tests(actors).


:- begin_tests(toplevels).

test(simple, Results == [a,b,c]) :-
   toplevel_spawn(Pid, [
       session(false),
       monitor(true)
   ]),
   toplevel_call(Pid, p(X), [
       template(X)
   ]),
   receive({
       success(Pid, Results, false) -> 
           true
   }),
   receive({
       down(Pid, true) -> true
   }).
   
test(next_1, Results == [11,12]) :-
   toplevel_spawn(Pid, [
       session(false)
   ]),
   toplevel_call(Pid, between(1,12,N), [
       limit(5),
       template(N)
   ]),
   receive({
       success(Pid, [1,2,3,4,5], true) -> true
   }),
   toplevel_next(Pid),
   receive({
       success(Pid, [6,7,8,9,10], true) -> true
   }),
   toplevel_next(Pid),
   receive({
       success(Pid, Results, false) -> true
   }).

test(next_2, Results == [11,12]) :-
   toplevel_spawn(Pid, [
       session(false)
   ]),
   toplevel_call(Pid, between(1,12,N), [
       offset(2),
       limit(2),
       template(N)
   ]),
   receive({
       success(Pid, [3,4], true) -> true
   }),
   toplevel_next(Pid, [
       limit(6)
   ]),
   receive({
       success(Pid, [5,6,7,8,9,10], true) -> true
   }),
   toplevel_next(Pid),
   receive({
       success(Pid, Results, false) -> true
   }).
   
test(next_wrong_order, Result == true) :-
   toplevel_spawn(Pid, [
       session(false),
       monitor(true)
   ]),
   toplevel_next(Pid,[
       limit(5)
   ]),
   toplevel_next(Pid,[
       limit(5)
   ]),
   toplevel_call(Pid, between(1,12,N), [
       limit(2),
       template(N)
   ]),
   receive({
       success(Pid, [1,2], true) -> true
   }),
   receive({
       success(Pid, [3,4,5,6,7], true) -> true
   }),
   receive({
       success(Pid, [8,9,10,11,12], false) -> true
   }),
   receive({
       down(Pid, Result) -> true
   }).

test(exit_false, Results == kill) :-
   toplevel_spawn(Pid, [
       session(true),
       monitor(true)
   ]),
   toplevel_call(Pid, (X = a ; X = b), [
       limit(5),
       template(X)
   ]),
   receive({
       success(Pid, [a,b], false) -> true
   }),
   toplevel_call(Pid, true, [
       template(.)
   ]),
   receive({
       success(Pid, [.], false) -> true
   }),
   toplevel_call(Pid, true),
   receive({
       success(Pid, [true], false) -> true
   }),
   toplevel_call(Pid, fail),
   receive({
       failure(Pid) -> true
   }),
   toplevel_exit(Pid, kill),
   receive({
       down(Pid, Results) -> true
   }).
   
test(stop, Results = [a]) :-
   toplevel_spawn(Pid, [
       session(false)
   ]),
   toplevel_call(Pid, p(X), [
       limit(1),
       template(X)
   ]),
   toplevel_stop(Pid),
   receive({
       success(Pid, Results, true) -> true
   }).

test(failure, Result = failure) :-
   toplevel_spawn(Pid, [
       session(false),
       monitor(true)
   ]),
   toplevel_call(Pid, fail),
   receive({
       failure(Pid) -> 
          Result = failure
   }),
   receive({
       down(Pid, true) -> true
   }).
   
test(exception, Error = error(existence_error(procedure, _:unknown/0),_)) :-
   toplevel_spawn(Pid, [
       session(false)
   ]),
   toplevel_call(Pid, unknown),
   receive({
       error(Pid, Error) -> true
   }).

test(output, Results = [.]) :-
   toplevel_spawn(Pid, [
       session(false),
       monitor(true)
   ]),
   toplevel_call(Pid, (output(a), output(b)), [
       template(.)
   ]),
   receive({
       output(Pid, a) -> true
   }),
   receive({
       success(Pid, Results, false) -> true
   }), 
   receive({
       output(Pid, b) -> true
   }),  
   receive({
       down(Pid, true) -> true
   }).

test(input, Results == true) :-
   toplevel_spawn(Pid, [
       session(false),
       monitor(true)
   ]),
   toplevel_call(Pid, (input(prompt, In), output(In)), [
       template(.)
   ]),
   receive({
       prompt(Pid, prompt) ->
           respond(Pid, hello)
   }),
   receive({
       output(Pid, hello) -> true
   }),
   receive({
       success(Pid, [.], false) -> true
   }),
   receive({
       down(Pid, Results) -> true
   }).

:- end_tests(toplevels).


:- begin_tests(compute_answer).

test(compute_answer_1a, Response == success([1,2,3,4,5],true)) :-
    trinity:compute_answer(between(1, 12, N), N, 0, 5, Response).

test(compute_answer_1b, Response == success([6,7,8,9,10],true)) :-
    trinity:compute_answer(between(1, 12, N), N, 5, 5, Response).
    
test(compute_answer_1c, Response == success([11,12],false)) :-
    trinity:compute_answer(between(1, 12, N), N, 10, 5, Response).

test(compute_answer_2, Response == failure) :-
    trinity:compute_answer(between(1, 12, N), N, 15, 5, Response).

test(compute_answer_3, 
        Response = error(error(existence_error(procedure, _:unknown/0),_))) :-
    trinity:compute_answer(unknown, unknown, 0, 1, Response).

:- end_tests(compute_answer).


:- begin_tests(programs).


test(program1, Msg == hello) :-
   spawn(echo_server, Pid, [
      monitor(true)
   ]),
   self(Self),
   Pid ! echo(Self, hello),
   receive({Msg -> true}),
   Pid ! echo(Self, hello),
   receive({Msg -> true}),
   exit(Pid, kill),
   receive({
       down(Pid, kill) -> true
   }).
  
test(program2, Count == 3) :-
   spawn(count_server(0), Pid, [
      monitor(true)
   ]),
   self(Self),
   Pid ! count(Self),
   receive({Count1 -> true}),
   Pid ! count(Self),
   receive({Count2 -> true}),
   Count is Count1 + Count2,
   Pid ! stop,
   receive({
       down(Pid, true) -> true
   }).

test(program3, Messages == [high,high,low,low]) :-
    self(S),
    S ! 15-high, S ! 7-low, S ! 1-low, S ! 17-high,
    important(Messages),
    S ! 15-high, S ! 7-low, S ! 1-low, S ! 17-high,
    important(Messages).
    
test(program4, Response == ok(cheese)) :-
   spawn(fridge([]), Pid, [
       monitor(true)
   ]),
   store(Pid, cheese, ok),
   take(Pid, cheese, Response),
   Pid ! terminate,
   receive({
       down(Pid, true) -> true
   }).
    
test(program5, Response == ok(meat)) :-
   spawn(server(fridge, []), Pid, [
       monitor(true)
   ]),
   rpc_synch(Pid, store(meat), ok),
   rpc_synch(Pid, take(meat), Response),
   Pid ! upgrade(fridge),
   rpc_synch(Pid, store(meat), ok),
   rpc_synch(Pid, take(meat), Response),
   Pid ! terminate,
   receive({
       down(Pid, true) -> true
   }).

test(program6, Done == true) :-
   ring(12, hello),
   sleep(0.1),
   Done = true.
    
test(program7, Done == true) :-
    ping_pong,
    Done = true.

test(program8_myfindall_1, Results == [1,2,3]) :-
    myfindall(N, between(1,3,N), Results).
    
test(program8_myfindall_2, Results == []) :-
    myfindall(_N, fail, Results).
    
test(program8_myfindall_3, Error = error(_,_)) :-
    catch(myfindall(N, N is 1/0, _Results), Error, true).
        
:- end_tests(programs).


:- begin_tests(parallel).

test(parallel_success, Done == true) :-
    parallel([sleep(0.1),sleep(0.3),sleep(0.2)]),
    Done = true.

test(parallel_failure, Done == true) :-
    \+ parallel([sleep(1),fail,sleep(2)]),
    Done = true.

test(parallel_error, Done == true) :-
    catch(parallel([sleep(1),sleep(a),sleep(2)]),
          Error, true),
    nonvar(Error),
    Done = true.    
    
:- end_tests(parallel).
    
    
                /*******************************
                *        TEST UTILITIES        *
                *******************************/


p(a). p(b). p(c).

mortal(Who) :- human(Who).

human(socrates). 
human(plato).
human(aristotle).


                /*******************************
                *           PROGRAMS           *
                *******************************/

echo_server  :-          
   receive({            
      echo(Pid, Msg) ->
         Pid ! Msg,   
         echo_server  
   }).
    
count_server(Count0) :-                            
   receive({                         
      count(From) ->
         Count is Count0 + 1,              
         From ! Count,              
         count_server(Count);
      stop ->
         true       
   }).            

important(Messages) :-
   receive({
      Priority-Message if Priority > 10 ->
         Messages = [Message|MoreMessages],
         important(MoreMessages)
   },[ timeout(0),
       on_timeout(normal(Messages))
   ]).

normal(Messages) :-
   receive({
      _-Message ->
         Messages = [Message|MoreMessages],
         normal(MoreMessages)
   },[ timeout(0),
       on_timeout(Messages=[])
   ]).


fridge(FoodList0) :-
    receive({
        store(From, Food) ->
            self(Self),
            From ! Self-ok,
            fridge([Food|FoodList0]);
        take(From, Food) ->
            self(Self),
            (   select(Food, FoodList0, FoodList)
            ->  From ! Self-ok(Food),
                fridge(FoodList)
            ;   From ! Self-not_found,
                fridge(FoodList0)
            );
        terminate ->
            true
    }).
   
store(Pid, Food, Response) :-
    self(Self),
    Pid ! store(Self, Food),
    receive({
        Pid-Response -> true
    }).
 
take(Pid, Food, Response) :-
    self(Self),
    Pid ! take(Self, Food),
    receive({
        Pid-Response -> true
    }).


server(Pred, State0) :-
    receive({
        rpc(From, Ref, Request) ->
            call(Pred, Request, State0, Response, State),
            From ! Ref-Response,
            server(Pred, State);
        upgrade(Pred1) ->
            server(Pred1, State0);
        terminate ->
            true
    }).

fridge(store(Food), FoodList, ok, [Food|FoodList]).
fridge(take(Food), FoodList, ok(Food), FoodListRest) :-
    select(Food, FoodList, FoodListRest), !.
fridge(take(_Food), FoodList, not_found, FoodList).

rpc_synch(To, Request, Response) :-
    self(Self),
    make_ref(Ref),
    To ! rpc(Self, Ref, Request),
    receive({
        Ref-Response -> true
    }).
   

% ring(12, hello).

ring(NumberProcesses, Message) :-
   spawn(create(NumberProcesses, Message)).
   
create(NumberProcesses, Message) :-
   self(Self),
   create(NumberProcesses, Self, Message).

create(1, NextProcess, Message) :- !,
   self(Self),
   format("Process ~p connected with ~p~n", [Self, NextProcess]),
   format("Process ~p injects message ~p~n", [Self, Message]),
   NextProcess ! Message.
create(NumberProcesses, NextProcess, Message) :-
   spawn(loop(NextProcess), Prev, [
       link(true)
   ]),
   format("Process ~p created and connected with ~p~n", [Prev, NextProcess]),
   NumberProcesses1 is NumberProcesses - 1,
   create(NumberProcesses1, Prev, Message).

loop(NextProcess) :-
   receive({
      Msg ->
         format("Got message ~p, passing it to ~p~n", [Msg, NextProcess]),
         NextProcess ! Msg
    }).


ping(0, Pong_Pid) :-
    Pong_Pid ! finished,
    format('Ping finished~n',[]).
ping(N, Pong_Pid) :-
    self(Self),
    Pong_Pid ! ping(Self),
    receive({
        pong -> 
            format('Ping received pong~n',[])
    }),
    N1 is N - 1,
    ping(N1, Pong_Pid).
    
pong :-
    receive({
        finished ->
            format('Pong finished~n',[]);
        ping(Ping_Pid) ->
            format('Pong received ping~n',[]),
            Ping_Pid ! pong,
            pong
    }).
    
ping_pong :-
    spawn(pong, Pong_Pid),
    spawn(ping(3, Pong_Pid), Ping_Pid, [
        monitor(true)
    ]),
    receive({
       down(Ping_Pid, true) ->
          true
    }).

% ping-pong for benchmarking send and receive  
    
bm_ping(0, Pong_Pid) :-
    Pong_Pid ! finished.
bm_ping(N, Pong_Pid) :-
    self(Self),
    Pong_Pid ! ping(Self),
    receive({
        pong -> true
    }),
    N1 is N - 1,
    bm_ping(N1, Pong_Pid).
    
bm_pong :-
    receive({
        finished -> true;
        ping(Ping_Pid) ->
            Ping_Pid ! pong,
            bm_pong
    }).
    
bm_ping_pong(N) :-
    spawn(bm_pong, Pong_Pid),
    spawn(bm_ping(N, Pong_Pid), Ping_Pid, [
        monitor(true)
    ]),
    receive({
       down(Ping_Pid, true) ->
          true
    }).



restarter(Init, Name, Count) :-
   spawn(restarter_loop(Init, Name, Count), _, [
      monitor(true)
   ]).

restarter_loop(Init, Name, Count0) :-
   spawn(Init, Pid, [
      monitor(true)
   ]),
   register(Name, Pid),
   receive({
      down(Pid, true) ->
         writeln('normal shutdown received') ; 
      down(Pid, _Anything) ->
         (   Count0 == 0
         ->  true
         ;   Count is Count0 - 1,
             restarter_loop(Init, Name, Count)
         )
    }).


search(Template, Goal, Pid) :-
    search(Template, Goal, Pid, []).
    
search(Template, Goal, Pid, Options) :-
    self(Self),
    spawn(goal(Template, Goal, Pid, Self), Pid,  [
          monitor(true)
        | Options
    ]).
    
goal(Template, Goal, Pid, Parent) :-
    call_cleanup(Goal, Det=true),
    (   var(Det)
    ->  Parent ! success(Pid, Template, true),
        receive({
            next -> fail ;
            stop ->
                Parent ! stopped(Pid)
        })
    ;   Parent ! success(Pid, Template, false)
    ).
   

% myfindall

myfindall(Template, Goal, Solutions) :-
    toplevel_spawn(Pid, [
        session(false)
    ]),
    toplevel_call(Pid, Goal, [
        template(Template)
    ]),
    receive({
        success(Pid, Solutions, false) ->
            true ;
        failure(Pid) ->
            Solutions = [] ;
        error(Pid, Error) ->
            throw(Error)
    }).
    
    
% Benchmarking -- see p. 106 in Erlang Programming

start(Num) :-
    self(Self),
    start_proc(Num, Self).
        
start_proc(0, Pid) :- !,
    Pid ! ok.
start_proc(Num, Pid) :-
    Num1 is Num-1,
    spawn(start_proc(Num1, Pid), NPid),
    NPid ! ok,
    receive({ok -> true}).
    

% A bigger program
    
sleep :-
    Time is random_float/10,
    sleep(Time).

doForks(ForkList) :-
    receive({
        {grabforks, {Left, Right}} ->
            subtract(ForkList, [Left,Right], ForkList1),
            doForks(ForkList1);
        {releaseforks, {Left, Right}} -> 
            doForks([Left, Right| ForkList]);
        {available, {Left, Right}, Sender} ->
            (   member(Left, ForkList),
                member(Right, ForkList)
            ->  Bool = true
            ;   Bool = false
            ),
            Sender ! {areAvailable, Bool},
            doForks(ForkList);
        {die} -> 
            format("Forks put away.~n")
    }).

areAvailable(Forks, Have) :-
    self(Self),
    forks ! {available, Forks, Self},
    receive({
        {areAvailable, false} ->
            Have = false;
        {areAvailable, true} -> 
            Have = true
    }).

processWaitList([], false).
processWaitList([H|T], Result) :-
    {Client, Forks} = H,
    areAvailable(Forks, Have),
    (   Have == true
    ->  Client ! {served},
        Result = true
    ;   Have == false
    ->  processWaitList(T, Result)
    ).

doWaiter([], 0, 0, false) :-
    forks ! {die},
    format("Waiter is leaving.~n"),
    diningRoom ! {allgone}.
doWaiter(WaitList, ClientCount, EatingCount, Busy) :-
    receive({
        {waiting, Client} ->
            WaitList1 = [Client|WaitList], % add to waiting list
            (   Busy == false,
                EatingCount < 2
            ->  processWaitList(WaitList1, Busy1)
            ;   Busy1 = Busy
            ),
            doWaiter(WaitList1, ClientCount, EatingCount, Busy1);
        {eating, Client} ->
            subtract(WaitList, [Client], WaitList1),
            EatingCount1 is EatingCount+1,
            doWaiter(WaitList1, ClientCount, EatingCount1, false);
        {finished} ->
            processWaitList(WaitList, R1),
            EatingCount1 is EatingCount-1,
            doWaiter(WaitList, ClientCount, EatingCount1, R1) ;
        {leaving} ->
            ClientCount1 is ClientCount - 1,
            flag(left_received, N, N+1),
            doWaiter(WaitList, ClientCount1, EatingCount, Busy)
    }).

philosopher(Name, _Forks, 0) :-
    format("~s is leaving.~n", [Name]),
    waiter ! {leaving},
    flag(left, N, N+1).
philosopher(Name, Forks, Cycle) :-
    self(Self),
    format("~s is thinking (cycle ~w).~n", [Name, Cycle]),
    sleep,
    format("~s is hungry (cycle ~w).~n", [Name, Cycle]),
    waiter ! {waiting, {Self, Forks}}, % sit at table
    receive({
        {served} -> 
            forks ! {grabforks, Forks}, % grab forks
            waiter ! {eating, {Self, Forks}}, % start eating
            format("~s is eating (cycle ~w).~n", [Name, Cycle])
    }),
    sleep,
    forks ! {releaseforks, Forks}, % put forks down
    waiter ! {finished},
    Cycle1 is Cycle - 1,
    philosopher(Name, Forks, Cycle1).

dining :-    
    AllForks = [1, 2, 3, 4, 5],
    Clients = 5,
    self(Self),
    register(diningRoom, Self),
    spawn(doForks(AllForks), ForksPid),
    register(forks, ForksPid),
    spawn(doWaiter([], Clients, 0, false), WaiterPid),
    register(waiter, WaiterPid),
    Life_span = 20,
    spawn(philosopher('Aristotle', {5, 1}, Life_span)),
    spawn(philosopher('Kant', {1, 2}, Life_span)),
    spawn(philosopher('Spinoza', {2, 3}, Life_span)),
    spawn(philosopher('Marx', {3, 4}, Life_span)),
    spawn(philosopher('Russel', {4, 5}, Life_span)),
    receive({
        {allgone} -> 
            format("Dining room closed.~n")
    }),
    unregister(diningRoom),
    unregister(forks), 
    unregister(waiter).
    
    
% parallel/1    

parallel(Goals) :-
    maplist(par_call, Goals, Pids),
    maplist(par_yield(Pids), Pids, Goals).
    
par_call(Goal, Pid) :- 
    self(Self),
    spawn((call(Goal), Self ! Pid-Goal), Pid, [
        monitor(true)
    ]).

par_yield(Pids, Pid, Goal) :-
    receive({
        down(Pid, true) -> 
            true ;
        down(_, false) ->
            tidy_up_all(Pids),
            !, fail ;
        down(_, exception(E)) ->
            tidy_up_all(Pids),
            throw(E)
    }),
    receive({Pid-Goal -> true}).

tidy_up_all(Pids) :-
    maplist(tidy_up, Pids).
    
tidy_up(Pid) :-
    demonitor(Pid), 
    exit(Pid, kill),
    mailbox_rm(Pid).

mailbox_rm(Pid) :-
    receive({
        Msg if arg(1, Msg, Pid) ->
            mailbox_rm(Pid)
    },[
        timeout(0)
    ]).



test_parallel :-
    Goal = (sleep(1),sleep(3),sleep(2)),
    format("Running ~p~n",[Goal]),
    time(Goal), 
    fail.
test_parallel :-
    Goal = parallel([sleep(1),sleep(3),sleep(2)]),
    format("Running ~p~n",[Goal]),
    time(Goal),
    fail.
test_parallel :-
    Goal = parallel([sleep(1),fail,sleep(2)]),
    format("Running ~p~n",[Goal]),    
    (   time(Goal)
    ->  writeln('Error: Should not have succeeded')
    ;   writeln('Failed, as it should'),
        fail
    ).
test_parallel :-
    Goal = parallel([sleep(1),(sleep(3),fail),sleep(2)]),
    format("Running ~p~n",[Goal]),    
    (   time(Goal)
    ->  writeln('Error: Should not have succeeded')
    ;   writeln('Also failed, as it should, although it takes longer'),
        fail
    ).
test_parallel :-
    Goal = parallel([sleep(1),sleep(a),sleep(2)]),
    format("Running ~p~n",[Goal]),    
    catch(time(Goal), Error, true), 
    writeln('Error': Error),
    fail.
test_parallel :-
    writeln('Now, no more messages should be seen below.'),   
    flush.


   