:- use_module(trinity).

                /*******************************
                *           PROGRAMS           *
                *******************************/


% See 2.4.1 A priority queue example

important(Messages) :-
    receive({
        Priority-Message if Priority > 10 ->
            Messages = [Message|MoreMessages],
            important(MoreMessages)
    },[ timeout(0),
        on_timeout(normal(Messages))
    ]).

normal(Messages) :-
    receive({
        _-Message ->
            Messages = [Message|MoreMessages],
            normal(MoreMessages)
    },[ timeout(0),
        on_timeout(Messages=[])
    ]).


% See 2.4.3 A stateful count server

count_actor(Count0) :-                            
    receive({                         
        count(From) ->
            Count is Count0 + 1,              
            From ! count(Count),              
            count_actor(Count) ;
        stop ->
            true 
    }).           


% See 2.4.4 A bigger, tastier example

fridge(FoodList0) :-
    receive({
        store(From, Food) ->
            self(Self),
            From ! Self-ok,
            fridge([Food|FoodList0]);
        take(From, Food) ->
            self(Self),
            (   select(Food, FoodList0, FoodList)
            ->  From ! Self-ok(Food),
                fridge(FoodList)
            ;   From ! Self-not_found,
                fridge(FoodList0)
            );
        terminate ->
            true
    }).


% See 2.4.5 Hiding the details of protocols

store(Pid, Food, Response) :-
    self(Self),
    Pid ! store(Self, Food),
    receive({
        Pid-Response -> true
    }).
 
take(Pid, Food, Response) :-
    self(Self),
    Pid ! take(Self, Food),
    receive({
        Pid-Response -> true
    }).


% See 2.4.6 A universal stateful server with hot code swapping

server(Pred, State0) :-
    receive({
        rpc(From, Ref, Request) ->
            call(Pred, Request, State0, Response, State),
            From ! Ref-Response,
            server(Pred, State);
        upgrade(Pred1) ->
            server(Pred1, State0);
        terminate ->
            true
    }).


fridge(store(Food), FoodList, ok, [Food|FoodList]).
fridge(take(Food), FoodList, ok(Food), FoodListRest) :-
    select(Food, FoodList, FoodListRest), !.
fridge(take(_Food), FoodList, not_found, FoodList).


rpc_synch(To, Request, Response) :-
    self(Self),
    make_ref(Ref),
    To ! rpc(Self, Ref, Request),
    receive({
        Ref-Response -> true
    }).
   

% See 2.4.8 Prolog actors playing ping-pong

ping(0, Pong_Pid) :-
    Pong_Pid ! finished,
    format('Ping finished.~n',[]).
ping(N, Pong_Pid) :-
    self(Self),
    Pong_Pid ! ping(Self),
    receive({
        pong -> 
            format('Ping received pong.~n',[])
    }),
    N1 is N - 1,
    ping(N1, Pong_Pid).
    
pong :-
    receive({
        finished ->
            format('Pong finished.~n',[]);
        ping(Ping_Pid) ->
            format('Pong received ping.~n',[]),
            Ping_Pid ! pong,
            pong
    }).
    
ping_pong :-
    spawn(pong, Pong_Pid),
    spawn(ping(3, Pong_Pid), Ping_Pid, [
        monitor(true)
    ]),
    receive({
       down(Ping_Pid, true) ->
          true
    }).


% See 2.4.9 Parallel execution of concurrent programs   

parallel(Goals) :-
    maplist(par_call, Goals, Pids),
    maplist(par_yield(Pids), Pids, Goals).
    
par_call(Goal, Pid) :- 
    self(Self),
    spawn((call(Goal), Self ! Pid-Goal), Pid, [
        monitor(true)
    ]).

par_yield(Pids, Pid, Goal) :-
    receive({
        down(Pid, true) -> 
            true ;
        down(_, false) ->
            tidy_up_all(Pids),
            !, fail ;
        down(_, exception(E)) ->
            tidy_up_all(Pids),
            throw(E)
    }),
    receive({Pid-Goal -> true}).

tidy_up_all(Pids) :-
    maplist(tidy_up, Pids).
    
tidy_up(Pid) :-
    demonitor(Pid), 
    exit(Pid, kill),
    mailbox_rm(Pid).

mailbox_rm(Pid) :-
    receive({
        Msg if arg(1, Msg, Pid) ->
            mailbox_rm(Pid)
    },[
        timeout(0)
    ]).


test_parallel :-
    Goal = (sleep(1),sleep(3),sleep(2)),
    format("Running ~p~n",[Goal]),
    time(Goal), 
    fail.
test_parallel :-
    Goal = parallel([sleep(1),sleep(3),sleep(2)]),
    format("Running ~p~n",[Goal]),
    time(Goal),
    fail.
test_parallel :-
    Goal = parallel([sleep(1),fail,sleep(2)]),
    format("Running ~p~n",[Goal]),    
    (   time(Goal)
    ->  writeln('Error: Should not have succeeded')
    ;   writeln('Failed, as it should'),
        fail
    ).
test_parallel :-
    Goal = parallel([sleep(1),(sleep(3),fail),sleep(2)]),
    format("Running ~p~n",[Goal]),    
    (   time(Goal)
    ->  writeln('Error: Should not have succeeded')
    ;   writeln('Also failed, as it should, although it takes longer'),
        fail
    ).
test_parallel :-
    Goal = parallel([sleep(1),sleep(a),sleep(2)]),
    format("Running ~p~n",[Goal]),    
    catch(time(Goal), Error, true), 
    writeln('Error': Error),
    fail.
test_parallel :-
    writeln('Now, no more messages should be seen below.'),   
    flush.


% See 2.4.10 Creating supervision hierarchies

restarter(Goal, Name, Count) :-
   spawn(restarter_loop(Goal, Name, Count), _, [
      monitor(true)
   ]).

restarter_loop(Goal, Name, Count0) :-
   spawn(Goal, Pid, [
      monitor(true)
   ]),
   register(Name, Pid),
   receive({
      down(Pid, true) ->
         true ;
      down(Pid, _Anything) ->
         (   Count0 == 0
         ->  true
         ;   Count is Count0 - 1,
             restarter_loop(Goal, Name, Count)
         )
    }).


% See 2.5.2 A simple Prolog toplevel actor

simple_toplevel(Pid) :-
    simple_toplevel(Pid, []).

simple_toplevel(Pid, Options) :-
    self(Self),
    spawn(session(Pid, Self), Pid, Options).
    
session(Pid, Parent) :-
    receive({
        '$call'(Template, Goal) ->
            (   call_cleanup(Goal, Det=true), 
                (   var(Det)
                ->  Parent ! success(Pid, Template, true),
                    receive({
                        '$next' -> fail ;
                        '$stop' -> true
                    })
                ;   Parent ! success(Pid, Template, false)
                )
            ;   Parent ! failure(Pid)
            )       
    }),
    session(Pid, Parent).

simple_toplevel_call(Pid, Template, Goal) :-
    Pid ! '$call'(Template, Goal).
    
simple_toplevel_next(Pid) :-
    Pid ! '$next'.
    
simple_toplevel_stop(Pid) :-
    Pid ! '$stop'.


% See 3.4.5 Reconstructing findall/3

myfindall(Template, Goal, Solutions) :-
    toplevel_spawn(Pid, [
        session(false)
    ]),
    toplevel_call(Pid, Goal, [
        template(Template)
    ]),
    receive({
        success(Pid, Solutions, false) ->
            true ;
        failure(Pid) ->
            Solutions = [] ;
        error(Pid, Error) ->
            throw(Error)
    }).


% A bigger program spawning 7 actors solving the Dining Philosophers problem. Ported from:
% https://github.com/acmeism/RosettaCodeData/blob/master/Task/Dining-philosophers/Erlang/dining-philosophers.erl

    
sleep :-
    Time is random_float/10,
    sleep(Time).

doForks(ForkList) :-
    receive({
        {grabforks, {Left, Right}} ->
            subtract(ForkList, [Left,Right], ForkList1),
            doForks(ForkList1);
        {releaseforks, {Left, Right}} -> 
            doForks([Left, Right| ForkList]);
        {available, {Left, Right}, Sender} ->
            (   member(Left, ForkList),
                member(Right, ForkList)
            ->  Bool = true
            ;   Bool = false
            ),
            Sender ! {areAvailable, Bool},
            doForks(ForkList);
        {die} -> 
            format("Forks put away.~n")
    }).

areAvailable(Forks, Have) :-
    self(Self),
    forks ! {available, Forks, Self},
    receive({
        {areAvailable, false} ->
            Have = false;
        {areAvailable, true} -> 
            Have = true
    }).

processWaitList([], false).
processWaitList([H|T], Result) :-
    {Client, Forks} = H,
    areAvailable(Forks, Have),
    (   Have == true
    ->  Client ! {served},
        Result = true
    ;   Have == false
    ->  processWaitList(T, Result)
    ).

doWaiter([], 0, 0, false) :-
    forks ! {die},
    format("Waiter is leaving.~n"),
    diningRoom ! {allgone}.
doWaiter(WaitList, ClientCount, EatingCount, Busy) :-
    receive({
        {waiting, Client} ->
            WaitList1 = [Client|WaitList], % add to waiting list
            (   Busy == false,
                EatingCount < 2
            ->  processWaitList(WaitList1, Busy1)
            ;   Busy1 = Busy
            ),
            doWaiter(WaitList1, ClientCount, EatingCount, Busy1);
        {eating, Client} ->
            subtract(WaitList, [Client], WaitList1),
            EatingCount1 is EatingCount+1,
            doWaiter(WaitList1, ClientCount, EatingCount1, false);
        {finished} ->
            processWaitList(WaitList, R1),
            EatingCount1 is EatingCount-1,
            doWaiter(WaitList, ClientCount, EatingCount1, R1) ;
        {leaving} ->
            ClientCount1 is ClientCount - 1,
            flag(left_received, N, N+1),
            doWaiter(WaitList, ClientCount1, EatingCount, Busy)
    }).

philosopher(Name, _Forks, 0) :-
    format("~s is leaving.~n", [Name]),
    waiter ! {leaving},
    flag(left, N, N+1).
philosopher(Name, Forks, Cycle) :-
    self(Self),
    format("~s is thinking (cycle ~w).~n", [Name, Cycle]),
    sleep,
    format("~s is hungry (cycle ~w).~n", [Name, Cycle]),
    waiter ! {waiting, {Self, Forks}}, % sit at table
    receive({
        {served} -> 
            forks ! {grabforks, Forks}, % grab forks
            waiter ! {eating, {Self, Forks}}, % start eating
            format("~s is eating (cycle ~w).~n", [Name, Cycle])
    }),
    sleep,
    forks ! {releaseforks, Forks}, % put forks down
    waiter ! {finished},
    Cycle1 is Cycle - 1,
    philosopher(Name, Forks, Cycle1).

dining :-    
    AllForks = [1, 2, 3, 4, 5],
    Clients = 5,
    self(Self),
    register(diningRoom, Self),
    spawn(doForks(AllForks), ForksPid),
    register(forks, ForksPid),
    spawn(doWaiter([], Clients, 0, false), WaiterPid),
    register(waiter, WaiterPid),
    Life_span = 20,
    spawn(philosopher('Aristotle', {5, 1}, Life_span)),
    spawn(philosopher('Kant', {1, 2}, Life_span)),
    spawn(philosopher('Spinoza', {2, 3}, Life_span)),
    spawn(philosopher('Marx', {3, 4}, Life_span)),
    spawn(philosopher('Russel', {4, 5}, Life_span)),
    receive({
        {allgone} -> 
            format("Dining room closed.~n")
    }),
    unregister(diningRoom),
    unregister(forks), 
    unregister(waiter).
    
   