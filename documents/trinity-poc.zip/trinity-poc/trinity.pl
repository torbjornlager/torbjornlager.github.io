:- module(trinity,  
       [ spawn/1,                % :Goal
         spawn/2,                % :Goal, -Pid
         spawn/3,                % :Goal, -Pid, +Options
         self/1,                 % -Pid
         monitor/1,              % +Pid
         demonitor/1,            % +Pid
         register/2,             % +Name, +Pid
         unregister/1,           % +Name
         whereis/2,              % +Name, -Pid
         exit/1,                 % +Reason
         exit/2,                 % +Pid, +Reason
         (!)/2,                  % +Pid, +Message
         send/2,                 % +Pid, +Message
         input/2,                % +Prompt, ?Answer
         input/3,                % +Prompt, ?Answer, +Options
         respond/2,              % +Pid, +Answer
         output/1,               % +Term
         output/2,               % +Term, +Options
         receive/1,              % +ReceiveClauses
         receive/2,              % +ReceiveClauses, +Options
         make_ref/1,             % -Ref
         flush/0,                %
         toplevel_spawn/1,       % -Pid
         toplevel_spawn/2,       % -Pid, +Options
         toplevel_call/2,        % +Pid, :Goal
         toplevel_call/3,        % +Pid, :Goal, +Options
         toplevel_next/1,        % +Pid
         toplevel_next/2,        % +Pid, +Options
         toplevel_stop/1,        % +Pid                   
         toplevel_abort/1,       % +Pid    
         toplevel_exit/2,        % +Pid, +Reason
         rpc/2,                  % +URI, :Goal
         rpc/3,                  % +URI, :Goal, +Options
         node/1,                 % +Port

         op(800,  xfx, !),       %
         op(200,  xfx, @),       %
         op(1000, xfy, if)       %
       ]).

        
                /*******************************
                *             ACTOR            *
                *******************************/            

               
:- use_module(library(debug)).
:- use_module(library(option)).
:- use_module(library(random)).

:- meta_predicate
    spawn(0),
    spawn(0, -),
    spawn(0, -, +),
    receive(:, +).


%!  spawn(:Goal) is det.
%!  spawn(:Goal, -Pid) is det.
%!  spawn(:Goal, -Pid, +Options) is det.
%
%   Spawn a new process.  Options:
%
%     - monitor(+Bool)
%       Send monitor events to the creator if the argument is `true`.
%     - link(+Bool)
%       If true, exit the spawned process if we exit.

:- dynamic link/2.

spawn(Goal) :-
    spawn(Goal, _Pid).

spawn(Goal, Pid) :-
    spawn(Goal, Pid, []).

spawn(Goal, Pid, Options) :-
    thread_self(Self),
    make_pid(Pid),
    thread_create(start(Self, Pid, Goal, Options), Pid, [
        alias(Pid),
        at_exit(stop(Pid, Self))
    ]),
    thread_get_message(initialized(Pid)).


make_pid(Pid) :-
    random_between(10000000, 99999990, Num),
    atom_number(Pid, Num).
      
   
:- thread_local parent/1.

start(Parent, Pid, Goal, Options) :-
    assertz(parent(Parent)),
    option(link(Link), Options, true),
    (   Link == true
    ->  assertz(link(Parent, Pid))
    ;   true
    ),
    option(monitor(Monitor), Options, false),
    (   Monitor == true
    ->  assertz(monitor(Parent, Pid))
    ;   true
    ),
    thread_send_message(Parent, initialized(Pid)),
    call(Goal).
                                          

stop(Pid, Parent) :-
    thread_detach(Pid),
    retractall(link(Parent, Pid)),
    retractall(registered(_Name, Pid)),
    forall(retract(link(Pid, ChildPid)), 
           exit(ChildPid, linked)),
    down_reason(Pid, Reason),
    forall(retract(monitor(Other, Pid)), 
           Other ! down(Pid, Reason)).

down_reason(Pid, Reason) :-
    retract(exit_reason(Pid, Reason)),
    !.
down_reason(Pid, Reason) :-
    thread_property(Pid, status(Reason)).
   

%!  self(-Pid) is det.
%
%   Find who we are.

self(Self) :-
    thread_self(Self).


%!  monitor(+Pid) is det.
%!  demonitor(+Pid) is det.
%
%   Monitoring/demonitoring of processes.

:- dynamic monitor/2.

monitor(Name) :-
    registered(Name, Pid),
    !,
    monitor(Pid).
monitor(Pid) :-
    self(Self),
    assertz(monitor(Self, Pid)).


demonitor(Name) :-
    registered(Name, Pid),
    !,
    demonitor(Pid).
demonitor(Pid) :-
    self(Self),
    retractall(monitor(Self, Pid)).


%!  register(+Name, +Pid) is det.
%
%   Register the given Pid under the name Name.

:- dynamic registered/2.

register(Name, Pid) :-
    must_be(atom, Name),
    (   registered(_, Pid)
    ->  throw(process_already_has_a_name(Pid))
    ;   registered(Name, _)
    ->  throw(name_is_in_use(Name))
    ;   asserta(registered(Name, Pid))
    ).
    
%!  unregister(+Name) is det.
%

unregister(Name) :-
    retractall(registered(Name, _)).
    
%!  whereis(?Name, Pid) is det.
%

whereis(Name, Pid) :-
    must_be(atom, Name),
    registered(Name, Pid),
    !.
whereis(_Name, undefined).


%!  exit(+Reason)
%
%   Exit the calling process.

:- dynamic exit_reason/2.

exit(Reason) :-
    var(Reason),
    instantiation_error(Reason).
exit(Reason) :-
    self(Self),
    asserta(exit_reason(Self, Reason)),
    abort.


%!  exit(+Pid, Reason) is det.
%
%   Exit the actor known as Pid.

exit(Pid, Reason) :-
    catch(thread_signal(Pid, 
          exit(Reason)), 
          error(existence_error(_,_), _), 
          true).


%!  !(+Pid, +Message) is det.
%!  send(+Pid, +Message) is det.
%
%   Send Message to Pid.

Pid ! Message :-
    send(Pid, Message).

send(Name, Message) :-
    registered(Name, Pid),
    !,
    send(Pid, Message).
send(Pid, Message) :-
    catch(thread_send_message(Pid, Message),
          error(existence_error(_,_), _),
          true).
     

%!  output(+Term) is det.
%!  output(+Term, +Options) is det.
%
%   Send Term to the target process. Default is the parent.

output(Term) :-
    output(Term, []).
   
output(Term, Options) :-
    self(Self),
    parent(Parent),
    option(target(Target), Options, Parent),
    Target ! output(Self, Term).
    

%!  input(+Prompt, -Input) is det.
%!  input(+Prompt, -Input, +Options) is det.
%
%   Send Prompt to the target process and wait for input. Prompt may
%   be any term, compound or atomic. Default target is the parent.

input(Prompt, Input) :-
    input(Prompt, Input, []).
    
input(Prompt, Input, Options) :-
    self(Self),
    parent(Parent),
    option(target(Target), Options, Parent),
    Target ! prompt(Self, Prompt),
    receive({ 
       '$input'(Target, Input) ->
           true
    }).
   

%!  respond(+Pid, +Input) is det.
%
%   Send a response in the form of Term to aan actor Pid that
%   has prompted its parent process for input.

respond(Pid, Term) :-
    self(Self),
    Pid ! '$input'(Self, Term).


%!  receive(+ReceiveClauses) is semidet.
%!  receive(+ReceiveClauses, +Options) is semidet.
%
%   Erlang-style receive.

:- thread_local deferred/1.

receive(Clauses) :-
    receive(Clauses, []).

receive(Clauses, Options) :-
    thread_self(Mailbox),
    (   clause(deferred(Msg), true, Ref),
        select_body(Clauses, Msg, Body)
    ->  erase(Ref),
        call(Body)
    ;   receive(Mailbox, Clauses, Options)
    ).

receive(Mailbox, Clauses, Options) :-    
    (   thread_get_message(Mailbox, Msg, Options)
    ->  (   select_body(Clauses, Msg, Body)
        ->  call(Body)
        ;   assertz(deferred(Msg)),
            receive(Mailbox, Clauses, Options)
        )
    ;   option(on_timeout(Goal), Options, true),
        call(Goal)
    ).
    
select_body(_M:{Clauses}, Message, Body) :-
    select_body_aux(Clauses, Message, Body).

select_body_aux((Clause ; Clauses), Message, Body) :-
    (   select_body_aux(Clause,  Message, Body)
    ;   select_body_aux(Clauses, Message, Body)
    ).
select_body_aux((Head -> Body), Message, Body) :-
    (   subsumes_term(if(Pattern, Guard), Head)
    ->  if(Pattern, Guard) = Head,
        subsumes_term(Pattern, Message),
        Pattern = Message,
        catch(once(Guard), _, fail)
    ;   subsumes_term(Head, Message),
        Head = Message
    ).


                /*******************************
                *      VARIOUS UTILITIES       *
                *******************************/  
                

%!  flush is det.
%
%   Flush the contents of the mailbox.

flush :-
    receive({
       Message ->
          format("Shell got ~q~n",[Message]),
          flush
    },[ timeout(0)]).




is_pid(main) :- !.   
is_pid(Pid) :-
    atom_number(Pid, Num),
    integer(Num).
    
is_name(Name) :-
    atom(Name),
    \+ is_pid(Name).
    

make_ref(Pid) :-
    random_between(10000000, 99999999, Num),
    atom_number(Pid, Num).
   
   

                /*******************************
                *           TOPLEVEL           *
                *******************************/    
                 

%!  toplevel_spawn(-Pid) is det.
%!  toplevel_spawn(-Pid, +Options) is det.
%
%   Spawn a new toplevel.  Options:
%
%     - session(+Bool)
%       Determines if the toplevel is a session that can accept 
%       new goals after the first goal has run to completion. 
%       Defaults to false.
%     - target(+Target)
%       Send messages to Target. Default is the process that
%       called toplevel_spawn/1-2.

toplevel_spawn(Pid) :-
    toplevel_spawn(Pid, []).

toplevel_spawn(Pid, Options) :-
    self(Self),
    option(session(Session), Options, false),
    option(target(Target), Options, Self),
    spawn(ptcp(Pid, Target, Session), Pid, Options).


ptcp(Pid, Target, Session) :-
    catch(state_1(Pid, Target, Session), 
          '$abort_goal',
          ptcp(Pid, Target, Session)).
          

state_1(Pid, Target0, Session) :-
    receive({
        '$call'(Goal, Options) ->
            option(template(Template), Options, Goal),
            option(offset(Offset), Options, 0),
            option(limit(Limit0), Options, 10 000 000 000),
            option(target(Target1), Options, Target0),
            Limit = count(Limit0),
            state_2(Goal, Template, Offset, Limit, Pid, Answer),
            Target = target(Target1),
            arg(1, Target, Out),
            Out ! Answer,
            (   arg(3, Answer, true)
            ->  state_3(Limit, Target)  
            ;   true
            ) 
        }),
    (   Session == false
    ->  true
    ;   state_1(Pid, Target0, Session)
    ).


state_2(Goal, Template, Offset, Limit, Pid, Answer) :-
    answer(Goal, Template, Offset, Limit, Answer0),
    add_pid(Answer0, Pid, Answer).


state_3(Limit, Target) :-
    receive({
        '$next'(Options2) ->
            (   option(limit(NewLimit), Options2)
            ->  nb_setarg(1, Limit, NewLimit)
            ;   true
            ),
            (   option(target(NewTarget), Options2)
            ->  nb_setarg(1, Target, NewTarget)
            ;   true
            ),                                                         
            fail ;
        '$stop' -> true
    }).


answer(Goal, Template, Offset, Limit, Answer) :-
    catch(
       call_cleanup(slice(Goal, Template, Offset, Limit, Slice),
                    Det = true),
           Error, true),
    (   Slice == []
    ->  Answer = failure
    ;   nonvar(Error)
    ->  Answer = error(Error) 
    ;   var(Det)
    ->  Answer = success(Slice, true)
    ;   Det == true
    ->  Answer = success(Slice, false)
    ).


slice(Goal, Template, Offset, Limit, Slice) :-
    findnsols(Limit, Template, offset(Offset, Goal), Slice).


add_pid(success(Slice, More), Pid, success(Pid, Slice, More)).
add_pid(failure, Pid, failure(Pid)).
add_pid(error(Term), Pid, error(Pid, Term)). 



%!  toplevel_call(+Pid, :Goal) is det.
%!  toplevel_call(+Pid, :Goal, +Options) is det.

toplevel_call(Pid, Goal) :-
    toplevel_call(Pid, Goal, []).

toplevel_call(Pid, Goal, Options) :-
    Pid ! '$call'(Goal, Options).
    

%!  toplevel_next(+Pid) is det.
%!  toplevel_next(+Pid, +Options) is det.

toplevel_next(Pid) :-
    toplevel_next(Pid, []).

toplevel_next(Pid, Options) :-
    Pid ! '$next'(Options).    


%!  toplevel_stop(+Pid) is det.
    
toplevel_stop(Pid) :-
    Pid ! '$stop'.
    

%!  toplevel_abort(+Pid) is det.
%
%   Tell toplevel Pid to abort any goal that it currently runs. 

toplevel_abort(Pid) :-
    catch(thread_signal(Pid, throw('$abort_goal')), 
          error(existence_error(_,_), _), 
          true).    


%!  toplevel_exit(+Pid, +Reason) is det.

toplevel_exit(Pid, Reason) :-
    exit(Pid, Reason).


                 /*******************************
                 *             NDRPC            *
                 *******************************/    


:- use_module(library(http/http_open)).
:- use_module(library(url)).


rpc(URI, Goal) :-
    rpc(URI, Goal, []).

rpc(URI, Goal, Options) :-
    parse_url(URI, Parts),
    term_variables(Goal, Vars),
    Template =.. [v|Vars],
    format(atom(GoalAtom), "(~p)", [Goal]),
    format(atom(TemplateAtom), "(~p)", [Template]),
    option(limit(Limit), Options, 10 000 000 000),
    rpc_7(Template, 0, Limit, GoalAtom, TemplateAtom, Parts, Options).

rpc_7(Template, Offset, Limit, GoalAtom, TemplateAtom, Parts, Options) :-    
    parse_url(ExpandedURI, [
        path('/call'),
        search([goal=GoalAtom, template=TemplateAtom, 
                offset=Offset, limit=Limit, format=prolog])
      | Parts
    ]),
    setup_call_cleanup(
        http_open(ExpandedURI, Stream, Options),
        read(Stream, Answer),
        close(Stream)),
    rpc_8(Answer, Template, Offset, Limit, GoalAtom, TemplateAtom, Parts, Options).

rpc_8(success(Slice, true), Template, Offset, Limit, GoalAtom, TemplateAtom, Parts, Options) :-  !,
    (   member(Template, Slice)
    ;   NewOffset is Offset + Limit,
        format('% New HTTP request from offset ~w~n', [NewOffset]),
        rpc_7(Template, NewOffset, Limit, GoalAtom, TemplateAtom, Parts, Options)
    ).
rpc_8(success(Slice, false), Template, _, _, _, _, _, _) :-
    member(Template, Slice).
rpc_8(failure, _, _, _, _, _, _, _) :- fail.
rpc_8(error(Error), _, _, _, _, _, _, _) :- throw(Error). 



                 /*******************************
                 *             NODE             *
                 *******************************/    


:- use_module(library(http/http_server)).
:- use_module(library(http/http_error)).
:- use_module(library(settings)).

:- setting(cache_size, integer, 100, 'Max number of cache entries').
:- setting(timeout,    number,  100, 'Timeout in seconds').

:- http_handler(root(call), node_controller_isobase, []).

node_controller_isobase(Request) :-
    http_parameters(Request, [
        goal(GoalAtom, [atom]),
        template(TemplateAtom, [default(GoalAtom)]),
        offset(Offset, [integer, default(0)]),
        limit(Limit, [integer, default(10 000 000 000)]),
        format(Format, [atom, default(json)])
    ]),
    atomic_list_concat([GoalAtom,+,TemplateAtom], QTAtom),
    read_term_from_atom(QTAtom, Goal+Template, []),
    compute_answer(Goal, Template, Offset, Limit, Answer),
    respond_with_answer(Format, Answer).


node(Port) :-
    http_server(http_dispatch, [port(Port)]).


% Naive implementation. Replace the below implementation
% with these two lines if you want to test it:

% compute_answer(Goal, Template, Offset, Limit, Answer) :-
%    once(answer(Goal, Template, Offset, Limit, Answer)).

compute_answer(Goal, Template, Offset, Limit, Answer) :-
    goal_id(Goal-Template, Gid),
    (   cache_retract(Gid, Offset, Pid)
    ->  thread_self(Self),
        toplevel_next(Pid, [
            limit(Limit),
            target(Self)
        ])
    ;   toplevel_spawn(Pid, [exit(true)]),
        toplevel_call(Pid, Goal, [
            template(Template),
            offset(Offset),
            limit(Limit)
        ])
    ),
    setting(timeout, Timeout),
    receive({
        success(Pid, Slice, true) ->
            Index is Offset + Limit,
            cache_update(Gid, Index, Pid),
            Answer = success(Slice, true) ;
        success(Pid, Slice, false) ->
            Answer = success(Slice, false) ;
        failure(Pid) ->
            Answer = failure ;
        error(Pid, Error) -> 
            Answer = error(Error) 
    },[
        timeout(Timeout),
        on_timeout((Answer = error(timeout), 
                    toplevel_exit(Pid, kill)))
    ]).


:- dynamic cache/3.

goal_id(GoalTemplate, Gid) :-
    copy_term(GoalTemplate, Gid0),
    numbervars(Gid0, 0, _),
    term_hash(Gid0, Gid).
    
    
cache_retract(Gid, N, Pid) :-
    once(retract(cache(Gid, N, Pid))).

cache_update(Gid, N, Pid) :-
    assertz(cache(Gid, N, Pid)),
    setting(cache_size, Size),
    predicate_property(cache(_,_,_),
                       number_of_clauses(N)),
    N > Size -> cache_retract(_,_,_) ; true.
    
    
respond_with_answer(prolog, Answer) :- !,
    format('Content-type: text/plain; charset=UTF-8~n~n'),
    write_term(Answer, [
        quoted(true),
        ignore_ops(true),
        fullstop(true),
        nl(true),
        blobs(portray),
        portray_goal(portray_blob)
    ]).
respond_with_answer(json, _Answer) :-
    format('Content-type: text/plain; charset=UTF-8~n~n'),
    writeln('JSON output is not yet implemented').
    

